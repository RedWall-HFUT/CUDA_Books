#pragma once

template <typename T>
void sum(T* input_data, T* sum_res, unsigned int data_size, int method);