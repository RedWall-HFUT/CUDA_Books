#pragma once

template <class T>
void VectorAdd(T* val1, T* val2, int n);